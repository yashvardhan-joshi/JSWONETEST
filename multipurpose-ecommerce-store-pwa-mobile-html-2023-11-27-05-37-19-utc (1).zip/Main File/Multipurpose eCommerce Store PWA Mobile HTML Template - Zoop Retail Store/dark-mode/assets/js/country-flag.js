/*-------------------------------------Country Code-------------------------------------*/
$("#mobile_code").intlTelInput({
  initialCountry: "us",
  separateDialCode: true,
});